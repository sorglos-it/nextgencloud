export const ngc = true;
